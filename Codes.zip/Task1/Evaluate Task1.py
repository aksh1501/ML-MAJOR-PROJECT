import gym
import random
import numpy as np
from keras.models import load_model

model_file = "Model Task1.h5"

env = gym.make("CartPole-v1")
env.reset()

# load the model for the task
model = load_model(model_file)

model.summary()

scores = []
reward_list=[]

# run 100 episodes
for each_game in range(100):
    
    # reset variables
    score = 0
    prev_observation = []
    env.reset()

    # max. length of each episode is 500 steps
    for i in range(500):

        # uncomment line 31 to render
        # env.render()     

        # first action is taken randomly by the agent
        if len(prev_observation)==0:
            action = random.randrange(0,2)
        # corresponding actions are taken according to the model predictions
        else:
            action = np.argmax(model.predict(prev_observation.reshape(-1,4))[0])
        new_observation, reward, done, _ = env.step(action)
        prev_observation = new_observation
        score+=reward
        if done: 
            break
    scores.append(score)

# print the average score of 100 episodes
print('Average Score:',sum(scores)/len(scores))
