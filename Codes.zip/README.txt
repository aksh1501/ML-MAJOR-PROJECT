There is a folder for each task

Each folder contains a training, evaluating python script as well as our saved model and training plot

For Task1
To train, run "python3 'Train Task1.py'"
To evaluate, run "python3 'Evaluate Task1.py'" (uncomment line #31 to see the rendered output as well)

For Task2
To train, run "python3 'Train Task2.py'"
To evaluate, run "python3 'Evaluate Task2.py'" (uncomment line #31 to see the rendered output as well)

For Task3
To train, run "python3 'Train Task3.py'"
To evaluate, run "python3 'Evaluate Task3.py'" (uncomment line #31 to see the rendered output as well)