import gym
import numpy as np
import random

from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.optimizers import Adam

from collections import deque

import matplotlib.pyplot as plt

random.seed(69)

model_file = "Model Task3.h5"
plot_file = "Plot Task3.png"


# create a class for Deep Q-Network
class DQN:


	def __init__(self, env):

		# initialise the environment
		self.env = env

		# initialise the memory which will be used to train the model while replaying
		self.memory = deque(maxlen=10000)

		# initialise the discount factor
		self.gamma = 0.99

		# initialise parameters used to make random actions
		self.epsilon = 1.0
		self.epsilon_min = 0.01
		self.epsilon_decay = 0.99	

		# initialise the learning rate of the neural network
		self.learning_rate = 1e-3

		# initialise the #nodes in each layer of the neural network
		self.num_nodes = 32

		# initialise the activation functions used in the neural network
		self.activation_function = "relu"
		self.final_activation_function = "linear"

		# initialise the #possible actions in the environment
		self.num_actions = 2

		# initialise the loss function used by the neural network
		self.loss_function = "mse"

		# initialise the optimizer used by the neural network
		self.optimizer = Adam(lr=self.learning_rate)

		# initialise the learning rate of target_model weights
		self.tau = .125

		# initialise the models
		self.model = self.create_model()
		self.target_model = self.create_model()

		# initialise x,y lists which will used to plot the graph
		self.x = []
		self.y = []

	def create_model(self):

		# a series of dense layers will act as the neural network
		model = Sequential()
		model.add(Dense(self.num_nodes))
		model.add(Activation(self.activation_function))
		model.add(Dense(self.num_nodes))
		model.add(Activation(self.activation_function))
		model.add(Dense(self.num_nodes))
		model.add(Activation(self.activation_function))
		model.add(Dense(self.num_actions))
		model.add(Activation(self.final_activation_function))

		model.compile(loss=self.loss_function, optimizer=self.optimizer)

		return model

	def act(self, state):

		self.epsilon *= self.epsilon_decay
		self.epsilon = max(self.epsilon_min, self.epsilon)

		if np.random.random() < self.epsilon:
		# take a random action from the action_space
			return self.env.action_space.sample()

		# take action according to model's prediction
		return np.argmax(self.model.predict(state)[0])

	def remember(self, state, action, reward, new_state, done):

		# remember (state, action)--reward-->new_state		
		self.memory.append([state, action, reward, new_state, done])

	def replay(self):

		# select a batch from replay memory
		batch_size = min(32, len(self.memory))
		samples = random.sample(self.memory, batch_size)


		# for each sample predict the result using target model and then according to the future reward,
		# update the target, and train the model accordingly
		for sample in samples:
			state, action, reward, new_state, done = sample
			target = self.target_model.predict(state)
			if done:
				target[0][action] = reward
			else:
				Q_future = max(self.target_model.predict(new_state)[0])
				target[0][action] = reward + Q_future * self.gamma
			self.model.fit(state, target, epochs=1, verbose=0)

	def target_train(self):

		# update the weights of the target_model to slowly learn the weights which will optimise the final reward
		weights = self.model.get_weights()
		target_weights = self.target_model.get_weights()

		for i in range(len(target_weights)):
			target_weights[i] = weights[i] * self.tau + target_weights[i] * (1 - self.tau)
		self.target_model.set_weights(target_weights)

	def save_model(self):

		# save the model
		self.model.save(model_file)

	def plot(self):

		# plot #steps vs episode# and save the plot
		plt.plot(self.x,self.y)
		plt.ylabel('#steps')
		plt.xlabel('episode#')
		fig = plt.gcf()
		fig.savefig(plot_file)    


# setup the environment
env = gym.make("CartPole-v1")

episodes = 1000
episode_length = 500

target = 10
current = 0

# create a DQN object
dqn_agent = DQN(env=env)

for episode in range(episodes):

	# reset the environment
	cur_state = env.reset().reshape(1,4)    

	for step in range(episode_length):

		# take an action
		action = dqn_agent.act(cur_state)

		new_state, reward, done, _ = env.step(action)

		# env.render()

		new_state = new_state.reshape(1,4)
		dqn_agent.remember(cur_state, action, reward, new_state, done)

		dqn_agent.replay()
		dqn_agent.target_train()

		cur_state = new_state
		if done:
			break
		
	print("Episode #{} length: {}".format(episode+1, step+1))

	dqn_agent.x.append(episode+1)
	dqn_agent.y.append(step+1)

	# model/plot will be saved only if the agent survives the whole episode
	if step+1 < episode_length:
		current = 0
	else:
		current += 1
		dqn_agent.plot()
		dqn_agent.save_model()
		# stop training if agent is to pass 'target' episodes continuously
		if(current == target):
			break
